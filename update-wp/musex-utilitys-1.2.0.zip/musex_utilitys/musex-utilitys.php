<?php
/**
 * Plugin Name: MusexPress Utility
 * Plugin URI: http://www.musegain.com
 * Description: This plugin adds a MusexPress utility.
 * Version: 1.2.0
 * Author:Musegain.com
 * Author URI: http://www.musegain.com
 * License: GPL2l
 */

	add_action ( 'admin_menu', 'nusex_utility_menu' );
	function nusex_utility_menu() {
		add_menu_page ( 'MusexPress Utility', 
						'MusexPress Utility', 
						'manage_options', 
						'musex_utility.php', 
						'render_utility_script_page', 
						'dashicons-admin-generic',81 );
// 		aggiunge un sub menu
// 		add_submenu_page(
// 				'musex_utility.php',
// 				'URL Utility',
// 				'URL Utility',
// 				'manage_options',
// 				'render_url_utility',
// 				'render_url_utility' );		
	}
	
	add_action ( 'admin_menu', 'loadLibraries' );
	function loadLibraries() {
		wp_enqueue_script ( 'script' ,  plugin_dir_url ( __FILE__ )  .'javascript/script.js' ) ;
// 		wp_enqueue_style( 'style',  plugin_dir_url ( __FILE__ )  .'css/style.css' );
	}
	
	function render_utility_script_page(){		
		?>
		<h1 class="mx-util-title">MuexPress Utility</h1>
		<?php	
			if ($gestore = opendir('../')) {
				if($_POST['okButton']){
					changeExtentionFile($gestore);
				}else{
					listFile($gestore);
				}
			}else{
				?>
					<td>You don't have permissions to open the folder!</td>
				<?php
			}
	}

/**
 * 
 * @param unknown $gestore
 */
function listFile($gestore) {
	?>
		<h2 class="mx-util-title">This utility allows you to convert the HTML pages in the PHP pages for use your Adobe Muse Theme in MusexPress.</h2>			
			<form name="formList" id="formList" action=""  method='post'>								
				<table class='wp-list-table widefat fixed striped comments'>	
					<thead>
						<tr>
							<td class="manage-column column-cb check-column">
								<input type='checkbox' alt="Select All" name="selectAll" onclick="javascript:selectAllCheck();"/>
							</td>
							<th class="manage-column column-comment column-primary">File Name</th>
							<th class="manage-column column-comment column-primary">Extention</th>
							<th class="manage-column column-comment column-primary">New Extention</th>
						</tr>
					</thead>
					<tbody data-wp-lists="list:comment">
					<?php						
						$isChangeFile=false;
						while (false !== ($entrada = readdir($gestore))) {
							if ($entrada != "." && $entrada != ".." && !is_dir ($entrada)) {
								$porciones =explode(".", $entrada);
						  			if(null !==$porciones[1] && ($porciones[1]=='html' || $porciones[1]=='htm' )){
						  				$isChangeFile=true;
										?>
										<tr>
											<td data-th=''>
												<input type='checkbox'  onclick="javascript:validateCheck();" name=' fileName[]' value='<?php echo $entrada ?>' />
											</td>
											<td data-th='File Name'><?php echo $entrada ?></td>
											<td data-th='Extention'><?php echo $porciones[1] ?></td>
											<td data-th='New Extention'>PHP</td>	
										<?php	
						  			}
						  			?>
								</tr>
							<?php } ?>						
					<?php }
					closedir($gestore);
					?>
					</tbody>
				</table>
					<?php
						if($isChangeFile){
					?>
						<p><input type="submit" id="okButton" name="okButton" disabled="disabled"  value="OK"/></p>	
					<?php
						}else{	
						?>		
						<table class='wp-list-table widefat fixed striped comments'>				
							<tr>  
				    			<td>In the folder there aren't files with HTML or HTM extension.</td>
				    		</tr>
				    	</table>
						<?php }?>
			</form>	
			<?php
	}
	
	
/**
 * 
 * @param unknown $gestore
 */
function changeExtentionFile($gestore) {
	
	if(!empty($_POST['fileName'])){
	?>
		<table class='wp-list-table widefat fixed striped comments'>
		<tr>
			<th>Old File</th>
			<th>New File</th>
			<th>Result</th>
		</tr>
	<?php
		while (false !== ($entrada = readdir($gestore))) {
			if ($entrada != "." && $entrada != ".." && !is_dir ($entrada)){				
				foreach($_POST['fileName'] as $check) {			
					if($check==$entrada){
	?>
					<tr>
						<td data-th='Old Name'><?php echo $check ?></td>
	<?php
						$porciones =explode(".", $entrada);
						if(null !==$porciones[1] && ($porciones[1]=='html' || $porciones[1]=='htm' )){
							if (file_exists("../".$entrada)){
							
							if( rename("../".$entrada,  "../".$porciones[0].".php")){
					?>
							<td data-th='New File'><?php echo $porciones[0].".php"?></td>
							<td data-th='Result'><span class="dashicons dashicons-yes"></span></td>
					</tr>
					<?php
							}else{		
					?>
							<td data-th='New File'>No changed</td>
							<td data-th='Result'><span class="dashicons dashicons-no"></span></td>		
					</tr>
					<?php							
							}
							
							}									
					
						}
					}
				}				
			}			
		}		
		?>
		</table>
	<?php	
	closedir($gestore);
	}
}

	function render_url_utility(){
				
	}
	
	//custom updates/upgrades
	$this_file = __FILE__;
	$update_check = "http://www.ceppaloni.info/musex-plugins/plain-text.txt";
	require_once('gill-updates.php');
?>