

	function validateCheck(){
		var checks =  document.getElementsByName('formList')[0].getElementsByTagName('input');
		for(var i = 0; i <checks.length; ++i){
		    if(checks[i].checked && (checks[i].name !='selectAll' && checks[i].name !='okButton')){
		    	document.getElementById("okButton").disabled=false;	
		    	return;
		    }
		}
		document.getElementById("okButton").disabled=true;	
	}
	
	function selectAllCheck(){	
		var check =  document.getElementsByName('selectAll')[0].checked;
		var checks =  document.getElementsByName('formList')[0].getElementsByTagName('input');
		for(var i = 0; i <checks.length; ++i){
		  if(check.name !='selectAll'){
		    	checks[i].checked=check;	
		    	document.getElementById("okButton").disabled=!check;	
		  } 
		}
	}
	
	